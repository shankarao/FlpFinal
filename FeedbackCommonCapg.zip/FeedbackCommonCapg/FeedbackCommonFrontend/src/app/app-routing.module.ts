import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerfeedbackComponent } from './customerfeedback/customerfeedback.component';
import { MerchantComponent } from './merchant/merchant.component';


const routes: Routes = [
  {
    path:'customer',
    component:CustomerfeedbackComponent
  },
  {
    path:'merchant',
    component:MerchantComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

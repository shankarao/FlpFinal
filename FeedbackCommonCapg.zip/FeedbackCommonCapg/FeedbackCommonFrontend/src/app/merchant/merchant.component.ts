import { Component, OnInit } from '@angular/core';
import { FeedbackServiceService } from '../feedback-service.service';

@Component({
  selector: 'app-merchant',
  templateUrl: './merchant.component.html',
  styleUrls: ['./merchant.component.css']
})
export class MerchantComponent implements OnInit {
  responses: any[] = [];
  constructor(private feedbackService: FeedbackServiceService) { }
  ngOnInit() {
    this.feedbackService.getMerchant().subscribe(res => {
      this.responses = res;
      console.log(res);
    }, error => {
      alert("Failed to get Data");
      console.log(error);
    })

}
sendFeedback(fid:number,response:string)
{
  this.feedbackService.addResponse(fid,response).subscribe(res => {
    alert("added");
  }, error => {
    alert("Failed to add data");
  })
}
}

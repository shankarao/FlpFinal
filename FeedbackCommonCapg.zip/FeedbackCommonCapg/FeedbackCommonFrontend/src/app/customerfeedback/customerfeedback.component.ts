import { Component, OnInit } from '@angular/core';

import { FeedbackServiceService } from '../feedback-service.service';

@Component({
  selector: 'app-customerfeedback',
  templateUrl: './customerfeedback.component.html',
  styleUrls: ['./customerfeedback.component.css']
})
export class CustomerfeedbackComponent implements OnInit {

  constructor(private feedbackService: FeedbackServiceService) { }

  feedbacks: any[] = [];
  ngOnInit() {
    this.feedbackService.getCustomer().subscribe(res => {
      this.feedbacks = res;
      console.log(res);
    }, error => {
      alert("Failed to get Data");
      console.log(error);
    })
  }

  sendFeedback(mid: number, feed: string) {
    var obj: any = {
      customerId:100,
      merchantId: mid,
      feedback: feed
    }
    this.feedbackService.addFeedBack(obj).subscribe(res => {
      alert("added");
    }, error => {
      alert("Failed to add data");
    })
  }

}

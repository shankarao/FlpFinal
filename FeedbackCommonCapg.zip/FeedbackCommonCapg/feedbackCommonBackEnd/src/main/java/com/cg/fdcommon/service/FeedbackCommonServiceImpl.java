package com.cg.fdcommon.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fdcommon.beans.FeedbackCommon;
import com.cg.fdcommon.dao.FeedbackCommonRepository;

@Service
public class FeedbackCommonServiceImpl implements FeedbackCommonService {

	@Autowired
	private FeedbackCommonRepository feedbackCommonRepository;
	@Override
	public void addFeedbackCommon(FeedbackCommon common) {
		feedbackCommonRepository.save(common);
	}
	@Override
	public List<FeedbackCommon> getAllCustomer(int customerId) {
		return feedbackCommonRepository.getAllCustomer(customerId);
	}
	@Override
	public List<FeedbackCommon> getAllMerchant(int merchantId) {
		return feedbackCommonRepository.getAllMerchant(merchantId);
	}
	@Override
	public void addResponse(int fId, String response) throws Exception {
		
		Optional<FeedbackCommon> optional = feedbackCommonRepository.findById(fId);	
		if(!optional.isPresent())
			throw new Exception("Feedback id not Found");
		else {
			optional.get().setResponse(response);
			feedbackCommonRepository.save(optional.get());
		}
		
		
	}

	


	
}

package com.cg.fdcommon.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.fdcommon.beans.FeedbackCommon;

@Repository
public interface FeedbackCommonRepository extends JpaRepository<FeedbackCommon, Integer> {

	@Query("from FeedbackCommon where customerId=:customerId")
	public List<FeedbackCommon> getAllCustomer(@Param("customerId") int customerId);
	
	@Query("from FeedbackCommon where merchantId=:merchantId")
	public List<FeedbackCommon> getAllMerchant(@Param("merchantId") int merchantId);
	
	@Query("from FeedbackCommon where customerId=:customerId")
	public FeedbackCommon getBycustomerId(@Param("customerId") int customerId);
}

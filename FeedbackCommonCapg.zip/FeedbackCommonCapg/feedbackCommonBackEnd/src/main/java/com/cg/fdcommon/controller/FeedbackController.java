package com.cg.fdcommon.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.fdcommon.beans.FeedbackCommon;
import com.cg.fdcommon.service.FeedbackCommonService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class FeedbackController {

	@Autowired
	private FeedbackCommonService feedbackCommonService;

	@PostMapping("/addFeedback")
	public ResponseEntity<?> addFeedback(@RequestBody FeedbackCommon common) {
		System.out.println(common);
		feedbackCommonService.addFeedbackCommon(common);
		return new ResponseEntity<>(HttpStatus.OK);

	}

	@GetMapping("/feedback/customer/{customerId}")
	public List<FeedbackCommon> getCustomerFeedback(@PathVariable int customerId) {
		return feedbackCommonService.getAllCustomer(customerId);

	}
	
	@GetMapping("/feedback/merchant/{merchantId}")
	public List<FeedbackCommon> getMerchantFeedback(@PathVariable int merchantId) {
		return feedbackCommonService.getAllMerchant(merchantId);

	}
	
	@PostMapping("/feedback/response/{fId}/{response}")
	public ResponseEntity<?> addResponse(@PathVariable("fId") int fId,@PathVariable("response") String response){
		try {
			feedbackCommonService.addResponse(fId, response);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
	}

}

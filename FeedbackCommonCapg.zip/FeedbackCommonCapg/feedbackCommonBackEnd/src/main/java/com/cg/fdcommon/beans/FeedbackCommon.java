package com.cg.fdcommon.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class FeedbackCommon {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private int customerId;
	private int merchantId;
	private String feedback;
	private String response;
	public FeedbackCommon() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FeedbackCommon(int id, int customerId, int merchantId, String feedback, String response) {
		super();
		this.id = id;
		this.customerId = customerId;
		this.merchantId = merchantId;
		this.feedback = feedback;
		this.response = response;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "FeedbackCommon [id=" + id + ", customerId=" + customerId + ", merchantId=" + merchantId + ", feedback="
				+ feedback + ", response=" + response + "]";
	}
	
	

}
